export interface Customer {
  name: string;
  email: string;
  product: string;
  price: string;
  date: string;
  city: string;
  status: string;
}
