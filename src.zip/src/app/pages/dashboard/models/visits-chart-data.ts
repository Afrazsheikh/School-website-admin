export interface VisitsChartData {
  data: number[];
  registration: string;
  signOut: string;
  rate: string;
  all: string;
}
