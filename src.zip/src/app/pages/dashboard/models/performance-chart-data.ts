export interface PerformanceChartData {
  integration: number;
  sdk: number;
}
