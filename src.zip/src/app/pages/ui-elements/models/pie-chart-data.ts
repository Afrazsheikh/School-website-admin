export interface PieChartData {
  series: number[],
  labels: string[]
}
