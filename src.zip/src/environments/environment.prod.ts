export const environment = {
  production: true,
  hmr: false,
  apiBaseUrl: 'http://13.126.126.170/api/v1/',
  imageBaseUrl: 'http://13.126.126.170/api/v1/uploads/',
  docBaseUrl: 'http://13.126.126.170/api/v1/documents/',
};
